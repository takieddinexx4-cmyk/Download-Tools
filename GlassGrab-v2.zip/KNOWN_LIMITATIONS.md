# Known Limitations

1. **Gradle Wrapper JAR generated in CI**: Because this project was packaged in an offline environment without Maven downloads, `gradle/wrapper/gradle-wrapper.jar` is not bundled inside `GlassGrab.zip`. The companion `extract-and-build.yml` workflow automatically runs `gradle wrapper --gradle-version 9.6.0` before building.
2. **Parallel download concurrency enforcement**: The parallel download limit (1–5) is persisted in Proto DataStore and surfaced in Settings, while WorkManager schedules individual unique workers; adding a custom `Semaphore` or work-queue coordinator in `DownloadRepositoryImpl` will enforce strict simultaneous execution caps across all OEMs.
3. **Live byte-rate speed estimation**: `DownloadWorker` reports real percentage progress and ETA from `yt-dlp` callbacks; instantaneous MB/s speed parsing from yt-dlp stdout lines is currently simplified to focus on reliable progress and ETA updates.
4. **Roborazzi golden snapshots**: `GlassComponentsScreenshotTest` is configured and ready to record golden images (`./gradlew :core:design:recordRoborazziDebug`) on the first CI/local run with Android SDK available.
5. **Private / login-gated posts**: GlassGrab intentionally ships with zero accounts and no embedded browser cookie harvesting, so private or age-gated posts that require authentication return a friendly error instead of requesting credentials.
6. **Extractors break**: TikTok and YouTube extraction changes often. The engine auto-updates from yt-dlp nightly (stable fallback), but a fix may still take days. No code in this app can guarantee a given site works today.
7. **TikTok quality is capped by TikTok**: usually up to 1080p; no engine here can exceed what TikTok serves for a video. Cookie-dependent resolution (seen in the reference downloaders) is not supported because the app has no accounts.
8. **Unverified build**: this revision was edited without a compiler or device. Run `./gradlew detekt spotlessCheck testDebugUnitTest assembleDebug` in CI and fix anything it reports.
9. **Design catalog is preview-only**: it renders in Android Studio's Compose Preview with the non-blur fallback; real Haze blur must be checked on a device.

