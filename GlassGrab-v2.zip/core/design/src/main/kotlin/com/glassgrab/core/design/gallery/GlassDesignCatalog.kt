package com.glassgrab.core.design.gallery

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.glassgrab.core.design.components.GlassBadge
import com.glassgrab.core.design.components.GlassCard
import com.glassgrab.core.design.components.GlassFloatingBottomBar
import com.glassgrab.core.design.components.GlassNavItem
import com.glassgrab.core.design.components.GlassPrimaryButton
import com.glassgrab.core.design.components.GlassShimmerSkeleton
import com.glassgrab.core.design.components.WavyProgressIndicator
import com.glassgrab.core.design.theme.GlassGrabTheme
import com.glassgrab.core.design.theme.GlassThemeVariant
import com.glassgrab.core.design.tokens.GlassSpacing

/**
 * Design-system catalog, rendered by Android Studio's Compose Preview (and covered by the
 * Roborazzi screenshot test) instead of a screen inside the shipped app.
 *
 * Why: a runtime gallery needed a navigation route, a debug-only settings entry and a live Haze
 * background, and it failed on device. A preview has none of those moving parts, cannot reach
 * users, and still shows every surface and control. Blur needs a live backdrop, so previews show
 * the translucent fallback; check real blur on a device.
 */
@Composable
internal fun GlassDesignCatalog(modifier: Modifier = Modifier) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val sampleNav = remember {
        listOf(
            GlassNavItem("home", "Home", Icons.Rounded.Home),
            GlassNavItem("downloads", "Queue", Icons.Rounded.Download, badgeCount = 2),
            GlassNavItem("library", "Library", Icons.Rounded.VideoLibrary),
            GlassNavItem("settings", "Settings", Icons.Rounded.Settings),
        )
    }

    Column(
        modifier = modifier.padding(GlassSpacing.md),
        verticalArrangement = Arrangement.spacedBy(GlassSpacing.md),
    ) {
        Text("GlassGrab Design Catalog", style = MaterialTheme.typography.headlineMedium)

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(GlassSpacing.xs)) {
                Text("Glass card", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Translucent card with gradient border and inner glow.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(GlassSpacing.xs)) {
                    GlassBadge("Badge")
                    GlassBadge("AV1")
                }
            }
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(GlassSpacing.sm)) {
                Text("Progress and actions", style = MaterialTheme.typography.titleMedium)
                WavyProgressIndicator(progress = 0.68f)
                GlassPrimaryButton(text = "Primary action", icon = Icons.Rounded.Download, onClick = {})
            }
        }

        GlassShimmerSkeleton()

        GlassFloatingBottomBar(
            items = sampleNav,
            selectedIndex = selectedTab,
            onSelect = { selectedTab = it },
        )
    }
}

@Preview(name = "Catalog / Dark", showBackground = true, widthDp = 400, heightDp = 760)
@Composable
private fun GlassDesignCatalogDarkPreview() {
    GlassGrabTheme(variant = GlassThemeVariant.DARK, supportsRealBlur = false) {
        Surface { GlassDesignCatalog() }
    }
}

@Preview(name = "Catalog / Light", showBackground = true, widthDp = 400, heightDp = 760)
@Composable
private fun GlassDesignCatalogLightPreview() {
    GlassGrabTheme(variant = GlassThemeVariant.LIGHT, supportsRealBlur = false) {
        Surface { GlassDesignCatalog() }
    }
}
