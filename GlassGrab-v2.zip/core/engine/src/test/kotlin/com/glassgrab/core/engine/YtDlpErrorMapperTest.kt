package com.glassgrab.core.engine

import com.glassgrab.core.common.GlassError
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class YtDlpErrorMapperTest {

    @Test
    fun `webpage download failure is not misread as age restriction`() {
        val error = mapYtDlpErrorMessage("ERROR: Unable to download webpage: HTTP Error 500")
        assertTrue(error is GlassError.Unknown)
    }

    @Test
    fun `age confirmation is mapped to AgeRestricted`() {
        val error = mapYtDlpErrorMessage("Sign in to confirm your age")
        assertTrue(error is GlassError.AgeRestricted)
    }

    @Test
    fun `private video is mapped to PrivateOrRemoved`() {
        val error = mapYtDlpErrorMessage("ERROR: Private video. Sign in if you've been granted access")
        assertTrue(error is GlassError.PrivateOrRemoved)
    }

    @Test
    fun `offline is mapped to Offline`() {
        val error = mapYtDlpErrorMessage("Unable to resolve host \"example.com\"")
        assertTrue(error is GlassError.Offline)
    }
}
