package com.glassgrab.core.engine

import com.glassgrab.core.common.GlassError

/**
 * Maps yt-dlp error text to a typed [GlassError].
 *
 * Matches are deliberately specific phrases. The previous implementation matched bare substrings
 * such as "age" and "geo", which misclassified ordinary failures ("Unable to download webpage",
 * "...message...") as age-restricted and stopped retries.
 */
internal fun mapYtDlpErrorMessage(msg: String): GlassError {
    val lower = msg.lowercase()
    return when {
        lower.contains("drm") || lower.contains("widevine") ->
            GlassError.DrmNotSupported("DRM Protected", msg)
        lower.contains("confirm your age") ||
            lower.contains("age-restricted") ||
            lower.contains("age restricted") ||
            lower.contains("inappropriate for some users") ->
            GlassError.AgeRestricted(msg)
        lower.contains("not available in your country") ||
            lower.contains("geo restrict") ||
            lower.contains("geo-restrict") ||
            lower.contains("blocked it in your country") ->
            GlassError.GeoBlocked(msg)
        lower.contains("private video") ||
            lower.contains("video unavailable") ||
            lower.contains("has been removed") ||
            lower.contains("video has been deleted") ->
            GlassError.PrivateOrRemoved(msg)
        lower.contains("unsupported url") ->
            GlassError.UnsupportedUrl("", msg)
        lower.contains("unable to resolve host") || lower.contains("network is unreachable") ->
            GlassError.Offline(msg)
        lower.contains("no space left") ->
            GlassError.LowStorage(technicalDetail = msg)
        else -> GlassError.Unknown(msg)
    }
}
