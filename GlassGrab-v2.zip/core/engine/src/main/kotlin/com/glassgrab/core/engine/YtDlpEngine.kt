package com.glassgrab.core.engine

import android.content.Context
import com.glassgrab.core.common.GlassError
import com.glassgrab.core.common.GlassResult
import com.glassgrab.core.common.IoDispatcher
import com.glassgrab.core.domain.model.MediaItemInfo
import com.glassgrab.core.domain.model.Platform
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class DownloadProgressEvent(
    val progressPercent: Float,
    val etaSeconds: Long?,
    val statusLine: String,
)

@Singleton
class YtDlpEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher,
    private val parser: YtDlpJsonParser,
) {
    private val initMutex = Mutex()
    @Volatile
    private var initialized = false

    suspend fun ensureInitialized(): GlassResult<Unit> = withContext(ioDispatcher) {
        if (initialized) return@withContext GlassResult.Success(Unit)
        initMutex.withLock {
            if (initialized) return@withContext GlassResult.Success(Unit)
            runCatching {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                Aria2c.getInstance().init(context)
                initialized = true
                GlassResult.Success(Unit)
            }.getOrElse { t ->
                if (t is CancellationException) throw t
                GlassResult.Failure(GlassError.Unknown("Engine initialization failed: ${t.message}"))
            }
        }
    }

    suspend fun analyze(url: String): GlassResult<MediaItemInfo> = withContext(ioDispatcher) {
        val initResult = ensureInitialized()
        if (initResult is GlassResult.Failure) return@withContext initResult

        val platform = parser.detectPlatform(url)
        if (platform == Platform.TIKTOK) {
            return@withContext analyzeTikTok(url)
        }

        executeWithRetry(maxAttempts = 2, timeoutMs = 45_000L) {
            val request = YoutubeDLRequest(url).apply {
                addOption("--dump-single-json")
                addOption("--flat-playlist")
                addOption("--no-warnings")
                addOption("-S", "res,fps,br")
            }
            val response = YoutubeDL.getInstance().execute(request)
            parser.parseDumpJson(response.out, url)
        }
    }

    /**
     * TikTok strategy: delegate to yt-dlp's current TikTok extractor, which already prefers the
     * un-watermarked variants it can extract and switches between its own API/web paths.
     *
     * We deliberately do NOT hard-code mobile-API hostnames or install IDs: they rotate, and a
     * stale value silently returns empty responses. TikTok extraction breaks and is fixed often,
     * so freshness comes from the engine auto-update (nightly channel), not from guesses here.
     * The highest resolution actually offered is whatever TikTok serves for that video; it is
     * never assumed (see README, "Quality: what is and is not guaranteed").
     */
    private suspend fun analyzeTikTok(url: String): GlassResult<MediaItemInfo> {
        val result = executeWithRetry(maxAttempts = 3, timeoutMs = 40_000L) {
            val request = YoutubeDLRequest(url).apply {
                addOption("--dump-single-json")
                addOption("--no-warnings")
                addOption("--no-playlist")
            }
            val response = YoutubeDL.getInstance().execute(request)
            parser.parseDumpJson(response.out, url)
        }
        if (result is GlassResult.Success) return result

        val reason = (result as GlassResult.Failure).error.technicalDetail ?: "yt-dlp TikTok extractor failed"
        return GlassResult.Failure(
            GlassError.TikTokExtractionFailed(
                primaryReason = reason,
                fallbackReason = "no secondary extractor path",
                technicalDetail = reason,
            ),
        )
    }

    suspend fun download(
        processId: String,
        url: String,
        formatSelector: String,
        container: String,
        isAudioOnly: Boolean,
        includeSubtitles: Boolean,
        includeThumbnail: Boolean,
        outputDir: File,
        onProgress: (DownloadProgressEvent) -> Unit,
    ): GlassResult<File> = withContext(ioDispatcher) {
        val initResult = ensureInitialized()
        if (initResult is GlassResult.Failure) return@withContext initResult

        outputDir.mkdirs()
        val template = File(outputDir, "%(title).80B [%(id)s].%(ext)s").absolutePath

        executeWithRetry(maxAttempts = 2, timeoutMs = 30L * 60L * 1000L) {
            val request = YoutubeDLRequest(url).apply {
                addOption("-o", template)
                addOption("-f", formatSelector)
                addOption("-S", "res,fps,br")
                addOption("--continue")
                addOption("--no-mtime")
                addOption("--retries", "10")
                addOption("--fragment-retries", "10")
                addOption("--socket-timeout", "20")
                addOption("--concurrent-fragments", "4")
                addOption("--embed-metadata")
                if (isAudioOnly) {
                    addOption("-x")
                    addOption("--audio-format", container.lowercase())
                    addOption("--audio-quality", "0")
                } else {
                    addOption("--merge-output-format", container.lowercase())
                }
                if (includeSubtitles) {
                    addOption("--write-subs")
                    addOption("--embed-subs")
                    addOption("--sub-langs", "en,ar")
                }
                if (includeThumbnail) {
                    addOption("--write-thumbnail")
                }
            }

            YoutubeDL.getInstance().execute(request, processId) { progress, etaInSeconds, line ->
                onProgress(
                    DownloadProgressEvent(
                        progressPercent = progress.coerceIn(0f, 100f),
                        etaSeconds = etaInSeconds.takeIf { it >= 0L },
                        statusLine = line.orEmpty(),
                    ),
                )
            }

            outputDir.listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.lastModified() }
                ?: error("Download completed but output file was not found in ${outputDir.absolutePath}")
        }
    }

    fun cancelProcess(processId: String): Boolean =
        runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }.getOrDefault(false)

    /**
     * Updates the bundled yt-dlp. Nightly is tried first because site extractors (TikTok,
     * YouTube) break often and fixes land there first; stable is the fallback.
     */
    suspend fun updateEngine(): GlassResult<String> = withContext(ioDispatcher) {
        val initResult = ensureInitialized()
        if (initResult is GlassResult.Failure) return@withContext initResult
        runCatching<GlassResult<String>> {
            withTimeout(90_000L) {
                var lastError: Throwable? = null
                val channels = listOf(
                    YoutubeDL.UpdateChannel.NIGHTLY,
                    YoutubeDL.UpdateChannel.STABLE,
                )
                for (channel in channels) {
                    try {
                        val status = YoutubeDL.getInstance().updateYoutubeDL(context, channel)
                        val version = YoutubeDL.getInstance().version(context) ?: "Updated ($status)"
                        return@withTimeout GlassResult.Success(version)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        lastError = t
                    }
                }
                throw lastError ?: IllegalStateException("No yt-dlp update channel succeeded")
            }
        }.getOrElse { t ->
            if (t is CancellationException) throw t
            GlassResult.Failure(GlassError.EngineUpdateFailed(t.message))
        }
    }

    suspend fun currentVersion(): String = withContext(ioDispatcher) {
        ensureInitialized()
        runCatching { YoutubeDL.getInstance().version(context) ?: "Bundled" }.getOrDefault("Bundled")
    }

    private suspend fun <T> executeWithRetry(
        maxAttempts: Int,
        timeoutMs: Long,
        block: suspend () -> T,
    ): GlassResult<T> {
        var lastError: GlassError = GlassError.Unknown()
        repeat(maxAttempts) { attempt ->
            try {
                val value = withTimeout(timeoutMs) { block() }
                return GlassResult.Success(value)
            } catch (e: TimeoutCancellationException) {
                lastError = GlassError.Timeout("Operation exceeded ${timeoutMs / 1000}s")
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                lastError = mapThrowableToError(t)
                if (lastError is GlassError.PrivateOrRemoved ||
                    lastError is GlassError.AgeRestricted ||
                    lastError is GlassError.GeoBlocked ||
                    lastError is GlassError.UnsupportedUrl
                ) {
                    return GlassResult.Failure(lastError)
                }
            }
            if (attempt < maxAttempts - 1) {
                delay(1500L * (attempt + 1))
            }
        }
        return GlassResult.Failure(lastError)
    }

    internal fun mapThrowableToError(throwable: Throwable): GlassError =
        mapYtDlpErrorMessage(throwable.message.orEmpty())
}
