# GlassGrab

GlassGrab is a privacy-first, multi-module Android video downloader built with Kotlin, Jetpack Compose, Material 3 Expressive, Haze v2 frosted glass UI, Navigation 3, Room, WorkManager, Media3 ExoPlayer, and `youtubedl-android` (`yt-dlp` + FFmpeg + Aria2c).

- **Best quality the source actually offers** (resolution, fps, codec) with FFmpeg merging of separate video + audio streams, plus audio-only presets (MP3/M4A/Opus). Nothing is upscaled and nothing is promised beyond what the site serves, see "Quality: what is and is not guaranteed" below.
- **TikTok**: uses yt-dlp's TikTok extractor and only labels a stream "No Watermark" when the extractor did not flag it as watermarked. TikTok changes often, so the engine auto-updates from yt-dlp nightly and falls back to stable.
- **Zero ads, zero trackers, zero accounts**: all history stays on device in Room, and saved media goes straight to `Movies/GlassGrab` (or `Music/GlassGrab`) via scoped `MediaStore`.
- **RTL & localization**: full English and Arabic (`ar`) support with per-app locale switching.
- **DRM policy**: GlassGrab does not bypass DRM (Netflix, Disney+, Hulu, Prime Video, etc.) and clearly reports those links as unsupported.

## Upload to GitHub (No Manual Unzipping)

You do not need to unzip `GlassGrab.zip` on your phone or PC. Use the companion `extract-and-build.yml` workflow:

1. Create a new empty repository on GitHub (public or private).
2. In the GitHub web UI, click **Add file → Create new file**, name it `.github/workflows/extract-and-build.yml`, paste the contents of `extract-and-build.yml`, and commit.
3. Click **Add file → Upload files**, upload `GlassGrab.zip` directly to the repository root, and commit.
4. Open the **Actions** tab and wait for the **Extract & Build GlassGrab** workflow run to finish (it automatically unzips the project, deletes `GlassGrab.zip`, commits the files, and builds the debug APK in the same run).
5. Click the finished workflow run, scroll to **Artifacts**, and download **GlassGrab-debug-apk** to install `app-debug.apk` on your Android device.

## Local Build & Test

Requirements: JDK 21, Android SDK with API 37.1 (`compileSdk 37.1`), Gradle 9.6.0.

```bash
# Bootstrap wrapper if gradle-wrapper.jar is not yet generated
gradle wrapper --gradle-version 9.6.0

# Build debug APK
./gradlew assembleDebug

# Run unit tests (JUnit 5, MockK, Turbine)
./gradlew testDebugUnitTest

# Static quality checks
./gradlew detekt spotlessCheck
```

## Architecture

| Module | Responsibility |
| --- | --- |
| `:app` | Single-Activity Compose host, Navigation 3 (`NavDisplay`), `ACTION_SEND` share receiver, Hilt + WorkManager init, R8 rules |
| `:core:common` | `GlassResult`, `GlassError`, coroutine dispatchers, global `CoroutineExceptionHandler`, `DeviceCapabilities`, formatters |
| `:core:domain` | Pure models (`MediaItemInfo`, `MediaFormat`, `DownloadTask`, `UserPreferences`), repository contracts, use cases |
| `:core:engine` | `youtubedl-android` (`library`, `ffmpeg`, `aria2c`) wrapper, `YtDlpJsonParser`, `YtDlpErrorMapper`, retry/timeout |
| `:core:data` | Room database, ProtoBuf DataStore (`kotlinx-serialization-protobuf`), scoped `MediaStoreExporter`, `DownloadWorker`, `EngineUpdateWorker` |
| `:core:design` | All design tokens, dark/light/AMOLED/dynamic themes, Haze v2 `GlassCard` with fallback, `AnimatedMeshBackground`, `WavyProgressIndicator`, `GlassFloatingBottomBar`, `@Preview` design catalog (no runtime gallery screen) |
| `:feature:home` | URL input, clipboard auto-detect banner, shared link ingestion, platform badges |
| `:feature:formats` | Modal bottom sheet for 144p–8K video, audio-only, subtitles, thumbnail, and playlist/batch multi-select |
| `:feature:downloads` | Live queue manager with pause/resume/cancel/retry and wavy progress |
| `:feature:library` | Searchable, sortable download history with share, gallery open, delete, and built-in player launch |
| `:feature:player` | Media3 ExoPlayer with glass overlay header |
| `:feature:settings` | Theme, dynamic color, English/Arabic RTL language, default quality, parallel downloads, Wi-Fi-only, yt-dlp update |
| `:benchmark` | Baseline Profile generator and cold-startup Macrobenchmark |

## Dependency versions (checked 24 Nov 2026)

"Confirmed" means the version (or a newer patch) appeared in official release notes or in other projects' release notes found online. "Unconfirmed" means it could not be checked, so treat it as a guess and let CI tell you.

| Component | Version | Status |
| --- | --- | --- |
| Gradle | 9.6.0 | Confirmed as the minimum and default for AGP 9.5 (newer 9.x exists) |
| AGP | 9.5.2 | Confirmed (9.5.0 released Oct 2026; 9.5.1 and 9.5.2 seen in the wild); max API level 37 |
| Kotlin / KSP | 2.4.21 / 2.3.13 | Confirmed (2.3.12 also works) |
| `compileSdk` | 37.1 (`minorApiLevel = 1`) | Compose BOM 2026.11.01 reportedly needs 37.1; if the SDK platform is missing, install it or use 37 with BOM 2026.09.00 |
| Compose BOM | 2026.11.01 | Confirmed to exist |
| Material 3 | 1.5.0 pinned | Unconfirmed; pinning it next to the BOM can mismatch, prefer letting the BOM choose |
| Haze | 2.1.0 (`haze` + `haze-blur`) | 2.x stable confirmed (2.0.1 release; 2.1.0 docs); API `hazeBlur` / `HazeInput.Sources` matches the 2.0 migration guide |
| `youtubedl-android` (junkfood02) | 0.18.1 | Confirmed latest found; adds QuickJS so yt-dlp can solve YouTube JS challenges |
| Room / WorkManager | 2.8.5 / 2.12.0 | Confirmed |
| Coroutines / core-ktx | 1.11.0 / 1.19.1 | Confirmed |
| Lifecycle | 2.11.1 | Confirmed |
| Coil 3 | 3.6.3 | Confirmed (was 3.4.0) |
| Navigation 3, Hilt, Media3, Serialization, Testing libs | see `libs.versions.toml` | Unconfirmed |

## Quality: what is and is not guaranteed

- yt-dlp picks the best streams the site offers. YouTube can serve up to 8K only for videos uploaded that way; TikTok commonly serves up to 1080p, and higher only when the video itself offers it.
- Since yt-dlp 2025.11.12, full YouTube support needs a JavaScript runtime plus the `yt-dlp-ejs` solver. `youtubedl-android` 0.18.1 supplies QuickJS; if YouTube formats go missing, update the engine first.
- MP3 output is re-encoded from the source audio (usually AAC or Opus around 128 to 256 kbps), so it cannot be better than the source.
- DRM content is not supported and is never bypassed. Login-gated content needs authentication that this app does not collect.
- Not compiled or run on a device by the author of this revision: build it in CI and smoke-test real links before trusting any of the above.
